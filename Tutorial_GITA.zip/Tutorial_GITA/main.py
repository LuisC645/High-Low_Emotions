#Se importan las librerías necesarias
#pydub: para cargar el archivo de audio
#numpy: para convertir el audio a un arreglo de numpy (NumericalPython)
#matplotlib: para graficar el audio

from pydub import AudioSegment
import numpy as np
import matplotlib.pyplot as plt

#Adquisición de datos
# Carga del audio
audio_wav = 'C:/Users/luisc/Escritorio/Tutorial_GITA/sources/voz1.wav'
audio_dc = AudioSegment.from_wav(audio_wav)


#Procesado
#Eliminar señal DC
dc_offset = np.mean(audio_dc.get_array_of_samples()) #.mean calcula la media de la señal y se la resta a cada punto del audio
audio = audio_dc - dc_offset

#Audio sin DC en formato numpy array
sample = np.array(audio.get_array_of_samples())

#Normalizarmos el audio
max_amp = max(abs(sample)) #Calculamos el valor absoluto máximo de la señal
sample_normalized = sample / max_amp #Normalizamos la señal

#Gráfica del audio
plt.figure(figsize=(8,4)) #Ancho, alto en pulgadas
plt.plot(sample_normalized)
plt.title('Voz 1')
plt.xlabel('Número de puntos')
plt.ylabel('Amplitud')
plt.grid(True)
plt.show()









