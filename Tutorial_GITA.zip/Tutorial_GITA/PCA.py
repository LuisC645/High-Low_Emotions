import numpy as np
import matplotlib.pyplot as plt
from sklearn.decomposition import PCA
from sklearn.preprocessing import StandardScaler

# Importacion librerias KNN
from sklearn.model_selection import train_test_split
from sklearn.neighbors import KNeighborsClassifier

# Importacion librerias SVM
from sklearn.svm import SVC

# Importacion librerias Matriz de cofusión
from sklearn.metrics import confusion_matrix

# Main ---------------------------------------------------------------

# leer datos y guardarlos
data_high = np.loadtxt('sources/high_emotions.txt')
data_low = np.loadtxt('sources/low_emotions.txt')

# Unir matrices
data = np.vstack((data_high, data_low))

# Estandarizar los datos, Normalizacion de caracteristicas
data_normalized = StandardScaler().fit_transform(data)

# Reducción de dimensionalidad
pca = PCA(n_components=2)
# ext = variable caracteristicas reducidas
ext_data = pca.fit_transform(data_normalized)

Y = np.zeros((len(data),))
Y[0:len(data_high)-1] = 1

# Se dividen los datos 70% para entrenamiento y 30% para test
data_train, data_test, Y_train, Y_test = train_test_split(
    ext_data, Y, test_size=0.3, random_state=42)

# KNN ---------------------------------------------------------------
# Se crea un clasificador KNN
knn = KNeighborsClassifier(n_neighbors=3)

# Entrenar el clasificador
knn.fit(data_train, Y_train)

# Realizar predicciones en los datos de prueba
Y_pred_knn = knn.predict(data_test)

# Calcular la precisión del modelo KNN
accuracy_knn = (Y_pred_knn == Y_test).mean()
# print(f'Precisión del modelo KNN: {accuracy_knn * 100: .2f}%')

# SVM ---------------------------------------------------------------
# Se crea un clasificador SVM
svm_classifier = SVC(kernel='linear')

# Entrenar el clasificador SVM
svm_classifier.fit(data_train, Y_train)

# Realizar predicciones en los datos de prueba
Y_pred_svm = svm_classifier.predict(data_test)

# Calcular la precisión del modelo SVM
accuracy_svm = (Y_pred_svm == Y_test).mean()
# print(f'Precisión del modelo SVM: {accuracy_svm * 100: .2f}%')

# Matriz de cofusión ------------------------------------------------
# Calcular la matriz de confusión
confusion_knn = confusion_matrix(Y_test, Y_pred_knn)
confusion_svm = confusion_matrix(Y_test, Y_pred_svm)

# Calcular la precisión utilizando la matriz de confusión
accuracy_cofusion_knn = (
    confusion_knn[0, 0] + confusion_knn[1, 1]) / confusion_knn.sum()
print(f'Precisión del modelo KNN: {accuracy_cofusion_knn * 100: .2f}%')

accuracy_cofusion_svm = (
    confusion_svm[0, 0] + confusion_svm[1, 1]) / confusion_svm.sum()
print(f'Precisión del modelo SVM: {accuracy_cofusion_svm * 100: .2f}%')

print()
print('Sensibilidad y Especificidad')

# Calcular la sensibilidad de KNN (Recall)
sensibilidad_knn = confusion_knn[1, 1] / \
    (confusion_knn[1, 0] + confusion_knn[1, 1])
# Calcular la especificidad de KNN
especificidad_knn = confusion_knn[0, 0] / \
    (confusion_knn[0, 0] + confusion_knn[0, 1])

print(f'Sensibilidad del modelo KNN: {sensibilidad_knn * 100: .2f}%')
print(f'Especificidad del modelo KNN: {especificidad_knn * 100: .2f}%')

# Calcular la sensibilidad de SVM (Recall)
sensibilidad_svm = confusion_svm[1, 1] / \
    (confusion_svm[1, 0] + confusion_svm[1, 1])
# Calcular la especificidad de SVM
especificidad_svm = confusion_svm[0, 0] / \
    (confusion_svm[0, 0] + confusion_svm[0, 1])

print(f'Sensibilidad del modelo SVM: {sensibilidad_svm * 100: .2f}%')
print(f'Especificidad del modelo SVM: {especificidad_svm * 100: .2f}%')


# # Plotear ----------------------------------------------------------

# # plt.scatter es para gráficos de dispersión
# plt.scatter(ext_data[0:len(data_high)-1, 0], ext_data[0:len(data_high)-1, 1],
#             color='Red', facecolor='none', marker='o', label='High emotions')
# plt.scatter(ext_data[len(data_high):, 0], ext_data[len(data_high):, 1],
#             color='Blue', facecolor='none', marker='o', label='Low emotions')

# plt.title('PCA para base de datos de emociones')
# plt.xlabel('PCA 1')
# plt.ylabel('PCA 2')
# plt.legend()
# plt.show()

# # Crear un gráfico de dispersión para visualizar el resultado
# plt.figure(figsize=(10, 6))

# # Separar los puntos de datos de prueba en dos grupos basados en las predicciones
# plt.scatter(data_test[Y_pred == 0][:, 0], data_test[Y_pred == 0]
#             [:, 1], c='blue', label='Low Emotions', marker='o')
# plt.scatter(data_test[Y_pred == 1][:, 0], data_test[Y_pred == 1]
#             [:, 1], c='red', label='High Emotions', marker='s')

# plt.xlabel('PCA 1')
# plt.ylabel('PCA 2')
# plt.title('Resultados del KNN después de PCA')
# plt.legend()
# plt.show()
